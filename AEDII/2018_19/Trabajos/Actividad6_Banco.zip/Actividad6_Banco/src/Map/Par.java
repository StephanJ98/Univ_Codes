package Map;

public class Par {
    int max, min;
    public int getMax(){
        return max;
    }
    public int getMin(){
        return min;
    }
    public void setMax(int m){
        max = m;
    }
    public void setMin(int m){
        min = m;
    }
}
