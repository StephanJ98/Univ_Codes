package Banco;

public class FondosInsuficientesException extends RuntimeException {

    public FondosInsuficientesException() {
        super();
    }

    public FondosInsuficientesException(String mensaje) {
        super(mensaje);
    }

}
