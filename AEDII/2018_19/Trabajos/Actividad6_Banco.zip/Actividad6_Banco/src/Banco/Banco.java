package Banco;

import java.util.Date;
import java.util.Iterator;
import mapa.HashMap;
import mapa.Map;

/**
 * Simula las operaciones basicas que se pueden realizar en un banco
 */
public class Banco {

    private final Map<Integer, Cuenta> cuentas;

    public Banco() {
        cuentas = new HashMap();
    }

    public void crearCuenta(int codigo, String titular) {
        Cuenta cuenta = new Cuenta(codigo, titular);
        cuentas.insertar(codigo, cuenta);
    }

    public float obtenerBalance(int codigo)
            throws CuentaNoEncontradaException {
        Cuenta cuenta = cuentas.get(codigo);
        if (cuenta != null) {
            return cuenta.getSaldo();
        } else {
            throw new CuentaNoEncontradaException("No existe la cuenta: " + codigo);
        }
    }

    public boolean depositar(int codigo, Date fecha, String concepto, float cantidad)
            throws CuentaNoEncontradaException {

        Cuenta cuenta = cuentas.get(codigo);

        if (cantidad <= 0) {
            System.out.println("Cantidad negativa");
            return false;
        } else if (cuenta == null) {
            throw new CuentaNoEncontradaException("No existe, la cuenta: " + codigo);
        }

        cuenta.depositar(fecha, concepto, cantidad);
        return true;
    }

    public void retirar(int codigo, Date fecha, String concepto, float cantidad)
            throws FondosInsuficientesException, CuentaNoEncontradaException {

        Cuenta cuenta = cuentas.get(codigo);

        if (cuenta == null) {
            throw new CuentaNoEncontradaException("No existe, la cuenta: " + codigo);
        }
        if (cantidad > cuenta.getSaldo()) {
            throw new FondosInsuficientesException("Saldo insuficiente, cuenta: " + codigo);
        }

        cuenta.retirar(fecha, concepto, cantidad);
    }

    public boolean transferencia(int codigo1, int codigo2, Date fecha, float cantidad)
            throws CuentaNoEncontradaException, FondosInsuficientesException {

        Cuenta cuenta1 = cuentas.get(codigo1);
        Cuenta cuenta2 = cuentas.get(codigo2);

        if (cuenta1 == null || cuenta2 == null) {
            throw new CuentaNoEncontradaException("No existe una de las dos cuentas");
        }

        if (cuenta1.getSaldo() < cantidad) {
            throw new FondosInsuficientesException("Saldo insuficiente, cuenta: " + codigo1);
        }

        if (cantidad <= 0) {
            System.out.println("Cantidad negativa");
            return false;
        } else {
            cuenta1.retirar(fecha, ("Transferencia a la cuenta " + codigo2), cantidad);
            cuenta2.depositar(fecha, ("Transferencia de la cuenta " + codigo1), cantidad);
            return true;
        }

    }

    @Override
    public String toString() {

        String cuentaS = "";
        Iterator<Cuenta> iter = cuentas.getValores();

        while (iter.hasNext()) {
            cuentaS += iter.next().toString() + "\n";
        }

        return cuentaS;
    }
}
