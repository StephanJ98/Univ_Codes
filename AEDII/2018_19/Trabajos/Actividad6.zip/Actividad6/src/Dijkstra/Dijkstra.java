package Dijkstra;

import grafo.*;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import mapa.*;

public class Dijkstra {

    public static <E> Map<Vertice<E>, Integer> dijkstra(Grafo<E, Integer> g, Vertice<E> v) {
        final Integer INFINI = Integer.MAX_VALUE;
        Map<Vertice<E>, Integer> distance = new HashMap<>();
        Set<Vertice<E>> porVisitar = new HashSet<>();
        Iterator<Vertice<E>> iterateurVert = g.vertices();
        while (iterateurVert.hasNext()) {
            Vertice<E> vert = iterateurVert.next();
            distance.insertar(vert, INFINI);
            porVisitar.add(vert);
        }
        distance.insertar(v, 0);
        while (!porVisitar.isEmpty()) {
            Vertice<E> vMinimo = minimum(distance, porVisitar.iterator());
            porVisitar.remove(vMinimo);
            Integer dis_vMinimo;
            dis_vMinimo = distance.get(vMinimo);
            if (!dis_vMinimo.equals(INFINI)) {
                Iterator<Arco<E, Integer>> arco = g.arcos();
                Integer pesoArcoElegido = 0;
                while (arco.hasNext()) {
                    Arco<E, Integer> a1 = arco.next();
                    Vertice<E> wDestino = a1.getDestino();
                    if (a1.getOrigen().equals(vMinimo) && porVisitar.contains(wDestino)) {
                        pesoArcoElegido = a1.getEtiqueta();
                        Integer distw = distance.get(wDestino);
                        if (dis_vMinimo + pesoArcoElegido < distw) {
                            distance.insertar(wDestino, dis_vMinimo + pesoArcoElegido);
                        }
                    }
                }
            }
        }
        return distance;
    }

    private static <E> Vertice<E> minimum(Map<Vertice<E>, Integer> d, Iterator<Vertice<E>> iPorVisitar) {
        Vertice<E> v, vertMin = iPorVisitar.next();
        Integer c, disMin = d.get(vertMin);
        while (iPorVisitar.hasNext()) {
            v = iPorVisitar.next();
            c = d.get(v);
            if (c < disMin) {
                vertMin = v;
                disMin = c;
            }
        }
        return vertMin;
    }
}
