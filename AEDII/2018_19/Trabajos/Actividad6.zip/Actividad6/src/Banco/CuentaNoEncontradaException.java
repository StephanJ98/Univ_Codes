package Banco;

public class CuentaNoEncontradaException extends RuntimeException {

    public CuentaNoEncontradaException() {
        super();
    }

    public CuentaNoEncontradaException(String mensaje) {
        super(mensaje);
    }

}
