package Banco;

import java.util.Date;

public class Movimiento {

    private static int idMove = 0;
    private final Date fechaValor;
    private final String concepto;
    private final float cantidad;

    public Movimiento(Date fecha, String con, float cant) {
        idMove++;
        fechaValor = fecha;
        concepto = con;
        cantidad = cant;
    }

    public float getCantidad() {
        return cantidad;
    }

    public Date getFechaValor() {
        return fechaValor;
    }

    public String getConcepto() {
        return concepto;
    }

}
