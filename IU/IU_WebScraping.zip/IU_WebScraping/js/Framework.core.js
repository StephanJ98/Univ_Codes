
function resetearform_base(){
	formactivo = document.getElementById('id_form_base');
	if (formactivo != null){
		document.getElementById('id_form_base').remove();
	}
}

// objetocontenedor: donde se va a colocar el objeto
// objetocontenido: el objeto que se va a colocar
function insertarelemento(objetocontenedor, objetocontenido){
	objetocontenedor.append(objetocontenido);
}

//padre: objeto donde se va a insertar
//datoselemento: info del elemento a crear e insertar
function crear(padre, datoselemento){

	elemento = document.createElement(datoselemento.element);
	for (var clave in datoselemento){
		if (clave != 'element'){
 			elemento[clave] = datoselemento[clave];
 		}
	}
	insertarelemento(padre, elemento);
}

function crearform(caja_form, formdef){

	crear(caja_form, formdef['form']);
	formulario = document.getElementById(formdef['form'].id);

	alert(formdef.keys());

}

function crearaddformframe(){

	defusuario = {
		'form':{
			'element':'form',
			'id':'id_form_base',
			'name' : 'form_base',
			'method':'post',
			'action':'miaction.php'
			},
		0:{
			'element':'input',
			'type':'text',
			'id':'id_dni',
			'name':'dni',
			'method':'post'
			},
		1:{
			'element':'button',
			'type':'submit',
			'id':'id_submitusuario',
			'name':'submitusuario',
				'hijos':{
					0:{
						'element':'img',
						'src':'./images/edit4.png',
						'width':'80',
						'height':'80'
						}
				}
			}
		};

	//caja contenedora
	caja = document.createElement('div');
	caja.id = 'id_caja_formulario';
	elbody = document.body;
	insertarelemento(elbody, caja);
	
	/*formulario = document.createElement('form');
	formulario.id = defusuario.form.id;
	insertarelemento(caja, formulario);*/

	crearform(document.getElementById('id_caja_formulario'),defusuario);

}

	//crear(document.getElementById('id_caja_formulario'),defusuario['form']);
/*
	campoinput = document.createElement(defusuario[0].element);
	campoinput.type = defusuario[0].type;
	campoinput.name = defusuario[0].name;
	insertarelemento(document.getElementById('id_form_base'), campoinput);
	document.getElementById('id_form_base').innerHTML += '<br>';

	camposubmit = document.createElement(defusuario[1].element);
	camposubmit.type = defusuario[1].type;
	camposubmit.name = defusuario[1].name;
	camposubmit.value = defusuario[1].value;	
	insertarelemento(document.getElementById('id_form_base'), camposubmit);

	//imagensubmit = document.createElement(defusuario[1].hijos[0].element);
	//for (var clave in defusuario[1].hijos[0]){
 		// Controlando que json realmente tenga esa propiedad
		//if (defusuario[1].hijos[0].hasOwnProperty(clave)) {
    		// asignar en pantalla la clave junto a su valor
    //		imagensubmit[clave] = defusuario[1].hijos[0][clave];
    	//}
    		
  	//}
  	crear(camposubmit, defusuario[1].hijos[0]);
	//imagensubmit.src = defusuario[1].hijos[0].src;
	//insertarelemento(camposubmit, imagensubmit);
*/


