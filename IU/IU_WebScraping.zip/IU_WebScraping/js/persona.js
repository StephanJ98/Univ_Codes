// devolverpersonas()
// funcion creada para devolver un array como el que recogeriamos de back al solicitar el contenido de la entidad persona

function devolverpersonas(){

	datospersonas = new Array();
	controlrol = 0;
	dnibase = '11111111';
	numeropersonas = 2;
	
	for (let i=0;i<numeropersonas;i++){
		
		persona = new Array();
		dnibase = String(Number(dnibase)+Number(23));
		persona['dni'] = dnibase + 'A';
		persona['nombre_persona'] = 'nombre persona'+i;
		persona['apellidos_persona'] = 'apellidos persona'+i;
		persona['fechaNacimiento_persona'] = '01/'+'01/'+String(Number(2000)+Number(i));
		persona['direccion_persona'] = 'Calle de la persona Nº '+i+' 32004 Ourense';
		persona['telefono_persona'] = 988387000+i;
		persona['email_persona'] = 'persona'+i+'@alumnos.uvigo.es';
		persona['foto_persona'] = './fotos/foto'+i+'.png';

		datospersonas[i] = persona;
	}

	return datospersonas;

}

//Función ajax con promesas
function devolverpersonasAjaxPromesa(){

	crearformoculto('form_generico','');
	insertacampo('form_generico','controlador', 'persona');
	insertacampo('form_generico','action', 'SEARCH');
	
	return new Promise(function(resolve, reject) {
		$.ajax({
			method: "POST",
			url: urlPeticionesAjax,
			data: $("#form_generico").serialize(),
		}).done(res => {
			if (res.ok != true) {
				reject(res);
			}
			else{
				resolve(res);
			}
		})
		.fail( function( jqXHR ) {
			mensajeHTTPFAIL(jqXHR.status);
		});
	});
}

async function devolverpersonasajax() {
	
	var idioma = getCookie('lang');

	await devolverpersonasAjaxPromesa()
		.then((res) => {
			
			getListPersonas(res.resource);
		
		})
		.catch((res) => {
			mensajeFAIL(res.code);
        	setLang(idioma);
		});

		document.getElementById('form_generico').remove();
}

function getListPersonas(listapersonas){

	$("#id_datospersonas").html('');

	for (let persona of listapersonas){

		datosfila = "'"+persona.dni+"',"
		+"'"+persona.nombre_persona+"',"
		+"'"+persona.apellidos_persona+"',"
		+"'"+persona.fechaNacimiento_persona+"',"
		+"'"+persona.direccion_persona+"',"
		+"'"+persona.telefono_persona+"',"
		+"'"+persona.email_persona+"',"
		+"'"+persona.foto_persona
		+"'";

		lineatabla = '<tr><td>'+persona['dni']+'</td><td>'+persona['nombre_persona']+'</td><td>'+persona['apellidos_persona']+'</td><td>'+persona['email_persona']+'</td><td>'+persona['foto_persona']+"</td>";
		botonedit = '<td><img class="titulo_edit" src="./images/edit4.png" onclick="crearformEDITpersona('+datosfila+');" width="50" height="50"></td>';
		botondelete = '<td><img class="titulo_delete" src="./images/delete4.png" width="50" height="50" onclick="crearformDELETEpersona('+datosfila+');"></td>';
		botonshowcurrent = '<td><img class="titulo_showcurrent" src="./images/detail4.png" width="50" height="50" onclick="crearformSHOWCURRENTpersona('+datosfila+')";></td>';

		lineatabla += botonedit+botondelete+botonshowcurrent+"</tr>";

		$("#id_datospersonas").append(lineatabla);
	}

}

function crearformADDpersona(){
	crearformaddframe();
}