
function resetearform_base(){
	formactivo = document.getElementById('id_form_base');
	if (formactivo != null){
		document.getElementById('id_form_base').remove();
	}
}

//campo: objeto a insertar en form
//form: objeto donde insertar
function insertarelemento(idcontenedor, idcontenido){
	alert(idcontenido+document.getElementById(idcontenido));
	document.getElementById(idcontenedor).append(document.getElementById(idcontenido));
}

//crearform()
//datosformulario: array de caracteristicas de formulario
//return: el id del formulario
// status: en progreso
// pendiente introduccion clases
function crearform(datosformulario){
	//formulario = document.createElement('form');
	formulario = document.getElementById(datosformulario['id']);
	formulario.id = datosformulario['id'];
	formulario.name = datosformulario['name'];
	formulario.action = datosformulario['action'];
	formulario.method = datosformulario['method'];
	formulario.onsubmit = datosformulario['onsubmit'];
	//document.getElementById(idcontenedor).append(formulario);
	return formulario.id;
}

//crearcampo()
//datoscampo: array de caracteristicas de campo
//idformulario: id del formulario donde colocar el campo
// crea el label correspondiente a traves del id con un atributo for de label ??
// status: en progreso
// pendiente introduccion clases

function crearcampoinput(datoscampo, idformulario){
	label = document.createElement('label');
	label.id = 'label_'+datoscampo['id'];
	label.htmlFor = datoscampo['id'];
	alert('1'+label);
	alert('2'+document.getElementById(label.id));
	insertarelemento(idformulario, label.id);

	campo = document.createElement(datoscampo['elemento']);
	campo.type = datoscampo['type'];
	campo.id = datoscampo['id'];
	campo.name = datoscampoform['name'];
	campo.onblur = datoscampoform['onblur'];
	campo.value = datoscampoform['value'];
	campo.readonly = datoscampoform['readonly'];
	

	insertarelemento(idformulario,campo.id);
	//document.getElementById(idformulario).append(label);
	//document.getElementById(idformulario).append(campo);
}

//crearcampobutton()
//datoscampo: array de caracteristicas del campo button
//datosimagen: array de caracteristicas de la imagen
//idformulario: id del formulario donde colocar el campo
// crea el label correspondiente a traves del id con un atributo for de label ??
// status: en progreso
// pendiente introduccion clases

function crearcampobutton(datoscampo, datosimagen='', idformulario){
	
	campo = document.createElement(datoscampo['elemento']);
	campo.type = datoscampo['type'];
	campo.id = datoscampo['id'];
	//campo.name = datoscampoform['name'];
	//campo.onblur = datoscampoform['onblur'];
	//campo.value = datoscampoform['value'];
	//campo.readonly = datoscampoform['readonly'];
	
	//if (datosimagen==''){}
	//else{
		imagen = document.createElement(datosimagen['elemento']);
		imagen.id = datosimagen['id'];
		insertarelemento(campo.id,imagen.id);
	//}

	document.getElementById(idformulario).append(campo);
}

function campoencampo(idcontenido, idcontenedor){
	esperar = 1;
	document.getElementById(idcontenedor).append(document.getElementById(idcontenido));
	esperar = 2;
	alert('entro en campoencampo');
}

function crearformaddframe(){

	// resetear formulario base
	// resetearform_base();
	//defino del formulario
	datosform = new Array();
	datosform['id'] = 'id_form_base';
	datosform['name'] = 'form_base';
	datosform['action'] = '';
	datosform['method'] = 'post';
	datosform['onsubmit'] = 'comprobarformpersona';

	//inserto en div contenedor de formularios
	idform = crearform(datosform);
	alert(document.getElementById('id_caja_formulario'));
	insertarelemento('id_caja_formulario', idform);
//
// crear dni
//
	//creo un campo para el formulario
	datoscampoform = new Array();
	datoscampoform['elemento'] = 'input';
	datoscampoform['type'] = 'text';
	datoscampoform['id'] = 'id_dni';
	datoscampoform['name'] = 'dni';
	datoscampoform['onblur'] = 'comprobar_dni';
	datoscampoform['value'] = '';
	datoscampoform['readonly'] = 'false';

	//inserto en el formulario el campo
	crearcampoinput(datoscampoform, 'id_form_base');
//
// crear boton submit
//
/*
	//creo un campo img para incluir en el button de submit
	imagensubmit = new Array();
	imagensubmit['elemento'] = 'img';
	imagensubmit['id'] = 'id_imagensubmit';
	imagensubmit['src'] = '';
	imagensubmit['title'] = 'titulo_add';
	imagensubmit['alt'] = 'titulo_add';

	//creo un campo button de submit para incluir en el formulario
	datoscampoform = new Array();
	datoscampoform['elemento'] = 'button';
	datoscampoform['type'] = 'submit';
	datoscampoform['id'] = 'id_accionsubmit';
	
	
	//inserto en el formulario el campo button
	crearcampobutton(datoscampoform, imagensubmit, 'id_form_base');
*/
	//pongo visible el formulario
	ponervisible('id_form_base');

}

