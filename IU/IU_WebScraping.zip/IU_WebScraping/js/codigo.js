function MostrarMensaje(){
	alert("Un mensaje de prueba");
}
