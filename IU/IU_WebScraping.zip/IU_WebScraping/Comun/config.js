//var urlPeticionesAjax = "http://193.147.87.202/Back/index.php";
var urlPeticionesAjax = "http://193.147.87.202/V0.2/index.php";