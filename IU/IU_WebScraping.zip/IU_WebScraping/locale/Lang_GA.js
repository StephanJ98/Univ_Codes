arrayGA={

	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////usuario////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
		//Codigos usuario
		'pagina_usuario_wellcome' : 'Xestión de usuarios',
		'pagina_login_wellcome': 'Autenticación usuarios',
		'dni' : 'DNI', 
		'id_dni' : 'DNI',
		'usuario' : 'Login Usuario',
		'contrasena': 'Contrasinal',
		'id_rol' : 'Rol Usuario',
		'text_formato_dni' : '8 letras e un número',
		'text_formato_usuario' : 'letras sen acentos e números',
		//Códigos error
		'usuario_corto_ko': 'Tamaño login demasiado corto (min 3 caracteres)',
		'usuario_largo_ko': 'Tamaño login demasiado largo (max 15 caracteres)',
		'usuario_formato_ko': 'O login contén carecteres non permitidos (solo letras sen acentos e números)',
		'contrasena_corto_ko': 'Tamaño contraseña demasiado corto (min 3 caracteres)',
		'contrasena_largo_ko': 'Tamaño contraseña demasiado largo (max 15 caracteres)',
		'contrasena_formato_ko': 'El contraseña contiene carecteres no permitidos (solo letras sin acentos y números)',
		'USUARIO_PASS_KO':'A contrasinal non é correcta',
		'USUARIO_LOGIN_KO':'Non existe o nome de usuario',

////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////persona////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
		//Codigos persona
		'pagina_persona_wellcome' : 'Xestión de persoas',
		'dni' : 'DNI', 
		'nombre_persona' : 'Nome persoa',
		'apellidos_persona' : 'Apelidos persoa',
		'fechaNacimiento_persona' : 'Data Nacemento persoa',
		'direccion_persona' : 'Dirección persoa',
		'telefono_persona' : 'Teléfono persoa',
		'email_persona' : 'Email persoa',
		'foto_persona' : 'Foto Persoa',
		'text_formato_dni' : '8 letras e un número',
		'text_formato_fechaNacimiento_persona' : 'dd/mm/aaaa',
		'text_formato_telefono' : '9 números',
		//Códigos error
		

	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////acciones////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
		//Codigos acciones
		'titulo_edit' : 'Editar',
		'titulo_delete' : 'Borrar', 
		'titulo_add' : 'Insertar',
		'titulo_search' : 'Buscar',
		'titulo_showcurrent' : 'Detalle'


		
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////Errores////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
		
}
