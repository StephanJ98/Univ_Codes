arrayEN={

	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////usuario////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
		//Codigos usuario
		'pagina_usuario_wellcome' : 'User Management',
		'pagina_login_wellcome': 'User Autentication',
		'dni' : 'DNI', 
		'id_dni' : 'DNI',
		'usuario' : 'User Login',
		'contrasena': 'Password',
		'id_rol' : 'User Role',
		'text_formato_dni' : '8 numbers and a letter',
		'text_formato_usuario' : 'letters without accent and numbers',
		//Códigos
		'usuario_corto_ko': 'Login size too short (min 3 characters)',
		'usuario_largo_ko': 'Login size too long (max 15 characters)',
		'usuario_formato_ko': 'Login contains not allowed characters (only letter without accent and numbers are allowed)',
		'contrasena_corto_ko': 'Password size too short (min 3 characters)',
		'contrasena_largo_ko': 'Password size too long (max 15 characters)',
		'contrasena_formato_ko': 'Password contains not allowed characters (only letter without accent and numbers are allowed)',
		'USUARIO_PASS_KO':'Wrong password',
		'USUARIO_LOGIN_KO':'User name not exists',

////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////persona////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
		//Codigos persona
		'pagina_persona_wellcome' : 'Person Management',
		'dni' : 'DNI', 
		'nombre_persona' : 'Person name',
		'apellidos_persona' : 'Person surname',
		'fechaNacimiento_persona' : 'Person birthday',
		'direccion_persona' : 'Person address',
		'telefono_persona' : 'Person phone number',
		'email_persona' : 'Person email',
		'foto_persona' : 'Person photografy',
		'text_formato_dni' : '8 letters and a number',
		'text_formato_fechaNacimiento_persona' : 'dd/mm/aaaa',
		'text_formato_telefono' : '9 numbers',
		//Códigos error
		

	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////acciones////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
		//Codigos acciones
		'titulo_edit' : 'Edit',
		'titulo_delete' : 'Delete', 
		'titulo_add' : 'Add',
		'titulo_search' : 'Search',
		'titulo_showcurrent' : 'Detail'


		
		
	
	////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////Errores////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////////
		

}
