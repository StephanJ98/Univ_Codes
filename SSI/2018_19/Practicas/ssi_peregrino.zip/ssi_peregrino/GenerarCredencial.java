/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ssi_peregrino;

import java.io.*;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import java.security.*;
import java.util.*;
import javax.crypto.*;

/**
 *
 * @author jordan
 */
public class GenerarCredencial {
    public static final void main(String[] args)throws NoSuchProviderException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException{
        
        Map<String,String> datos = leerDatos();
       
        String datosJson = map2json(datos);
        System.out.println("JSON: " + datosJson);
        byte[] resumen = generarResumen(datosJson);
        SecretKey Ks = generarClaveSecreta();
        byte[] datosEnc = encriptadoSimetrico(datosJson, Ks);
    
          
    }
    
    public static Map<String,String> leerDatos(){
        System.out.println("Introduzca los datos");

        Map<String, String> datos = new HashMap<String, String>();
        
        Scanner in = new Scanner(System.in);
        System.out.print("Nombre : ");
        String nombre = in.nextLine();
        datos.put("nombre", nombre);
        
        System.out.print("DNI  : ");
        String dni = in.nextLine();        
        datos.put("dni", dni);
        
        System.out.print("Domicilio  : ");
        String domicilio = in.nextLine();
        datos.put("domicilio", domicilio);
        in.close();
       
        System.out.print("Fecha Creación : ");
        String fecha = in.nextLine();
        datos.put("fecha", fecha);
        
        System.out.print("Lugar Creación : ");
        String lugar = in.nextLine();        
        datos.put("lugar", lugar);
        
        System.out.print("Motivaciones  : ");
        String motivaciones = in.nextLine();
        datos.put("motivaciones", motivaciones);
        in.close();
        
        return datos;
    }

    public static String map2json(Map<String, String> datos) {
        StringBuilder resultado = new StringBuilder();
        resultado.append('{');
        if (datos != null) {
            for (Map.Entry<String, String> entrada : datos.entrySet()) {
                if (resultado.length() > 1) { // Anadir separador ","
                    resultado.append(',');
                }
                resultado.append('\"');
                resultado.append(limpiarCadena(entrada.getKey()));
                resultado.append('\"');
                resultado.append(':');
                resultado.append('\"');
                resultado.append(limpiarCadena(entrada.getValue()));
                resultado.append('\"');
            }
        }
        resultado.append('}');
        return resultado.toString();
    }

    private static String limpiarCadena(String cadena) {
        return cadena.replaceAll("\\{|\\}|:|,|\\\"", "");
    }
    
    public static byte[] generarResumen(String json)throws NoSuchProviderException, NoSuchAlgorithmException {
        Security.addProvider(new BouncyCastleProvider());
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256","BC");
     
        messageDigest.update(json.getBytes());

        byte[] resumen = messageDigest.digest(); 
        
        return resumen;
    }
    public static SecretKey generarClaveSecreta() throws NoSuchAlgorithmException, NoSuchProviderException{
        KeyGenerator generadorDES = KeyGenerator.getInstance("DES","BC");
        generadorDES.init(56); // clave de 56 bits
        SecretKey clave = generadorDES.generateKey();

        System.out.println("CLAVE:");
        mostrarBytes(clave.getEncoded());
        System.out.println();
        return clave;
    }
    public static byte[] encriptadoSimetrico(String json, SecretKey clave)throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, FileNotFoundException, IOException{
        FileOutputStream out = new FileOutputStream(json+".cifrado");

        Cipher cifrador = Cipher.getInstance("DES/ECB/PKCS5Padding");
        cifrador.init(Cipher.ENCRYPT_MODE, clave);
          byte[] bufferCifrado = cifrador.doFinal(json.getBytes());
        out.write(bufferCifrado);
        out.close();
    
        return bufferCifrado;      
    }
    
    
    
    
    public static void mostrarBytes(byte [] buffer) {
		System.out.write(buffer, 0, buffer.length);
	} 
}
